'use strict';

/** @type {import('.')} */
module.exports = Error;
